package com.aonon.foldcollage;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Region;
import android.net.Uri;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

public class CollageView extends View {
    public enum Preset {
        V2("縦2分割", 2),
        H2("横2分割", 2),
        V3("縦3分割", 3),
        H3("横3分割", 3),
        DIAG2_R("斜め2 ／", 2),
        DIAG2_L("斜め2 ＼", 2),
        DIAG3_R("斜め3 ／", 3);

        public final String label;
        public final int cells;
        Preset(String label, int cells) { this.label = label; this.cells = cells; }
    }

    public interface Listener {
        void onRequestImage(int cellIndex);
        void onSelectionChanged(int cellIndex);
        void onStateChanged();
    }

    private static class ImageState {
        Uri uri;
        Bitmap bitmap;
        float zoom = 1f;
        float offsetX = 0f; // in cell-width units
        float offsetY = 0f; // in cell-height units
    }

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final List<ImageState> images = new ArrayList<>();
    private final ScaleGestureDetector scaleDetector;
    private Listener listener;
    private Preset preset = Preset.V2;
    private int selected = 0;
    private float lastX;
    private float lastY;
    private boolean moved;

    public CollageView(Context context) {
        super(context);
        setBackgroundColor(Color.rgb(11, 13, 17));
        setFocusable(true);
        for (int i = 0; i < 4; i++) images.add(new ImageState());

        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeJoin(Paint.Join.ROUND);
        text.setColor(Color.WHITE);
        text.setTextAlign(Paint.Align.CENTER);

        scaleDetector = new ScaleGestureDetector(context, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScale(ScaleGestureDetector detector) {
                ImageState st = images.get(selected);
                if (st.bitmap == null) return false;
                float next = st.zoom * detector.getScaleFactor();
                st.zoom = Math.max(1f, Math.min(6f, next));
                clampOffsets(selected);
                invalidate();
                changed();
                return true;
            }
        });
    }

    public void setListener(Listener listener) { this.listener = listener; }

    public Preset getPreset() { return preset; }

    public void setPreset(Preset p) {
        if (p == null) return;
        preset = p;
        if (selected >= p.cells) selected = p.cells - 1;
        invalidate();
        if (listener != null) listener.onSelectionChanged(selected);
        changed();
    }

    public int getSelectedCell() { return selected; }

    public void requestImageForSelected() {
        if (listener != null) listener.onRequestImage(selected);
    }

    public void setImageForCell(int index, Uri uri, Bitmap bitmap) {
        if (index < 0 || index >= images.size() || bitmap == null) return;
        ImageState st = images.get(index);
        if (st.bitmap != null && st.bitmap != bitmap && !st.bitmap.isRecycled()) {
            st.bitmap.recycle();
        }
        st.uri = uri;
        st.bitmap = bitmap;
        st.zoom = 1f;
        st.offsetX = 0f;
        st.offsetY = 0f;
        selected = index;
        invalidate();
        if (listener != null) listener.onSelectionChanged(selected);
        changed();
    }

    public void resetSelectedTransform() {
        ImageState st = images.get(selected);
        st.zoom = 1f;
        st.offsetX = 0f;
        st.offsetY = 0f;
        invalidate();
        changed();
    }

    public boolean isComplete() {
        for (int i = 0; i < preset.cells; i++) {
            if (images.get(i).bitmap == null) return false;
        }
        return true;
    }

    public Bitmap renderForExport(float aspectRatio, int maxEdgePx) {
        int outW;
        int outH;
        if (aspectRatio >= 1f) {
            outW = maxEdgePx;
            outH = Math.max(1, Math.round(maxEdgePx / aspectRatio));
        } else {
            outH = maxEdgePx;
            outW = Math.max(1, Math.round(maxEdgePx * aspectRatio));
        }
        Bitmap out = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(out);
        drawCollage(canvas, outW, outH, false);
        return out;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        drawCollage(canvas, getWidth(), getHeight(), true);
    }

    private void drawCollage(Canvas canvas, int width, int height, boolean interactive) {
        canvas.drawColor(Color.rgb(11, 13, 17));
        List<Path> paths = buildPaths(width, height);
        for (int i = 0; i < preset.cells; i++) {
            Path path = paths.get(i);
            RectF bounds = new RectF();
            path.computeBounds(bounds, true);
            ImageState st = images.get(i);

            canvas.save();
            canvas.clipPath(path);
            if (st.bitmap != null) {
                paint.setColor(Color.WHITE);
                Matrix m = matrixFor(st, bounds);
                canvas.drawBitmap(st.bitmap, m, paint);
            } else {
                paint.setColor(Color.rgb(31, 36, 46));
                canvas.drawRect(bounds, paint);
                if (interactive) drawPlaceholder(canvas, bounds, i);
            }
            canvas.restore();

            stroke.setColor(Color.argb(235, 255, 255, 255));
            stroke.setStrokeWidth(Math.max(2f, Math.min(width, height) * 0.004f));
            canvas.drawPath(path, stroke);

            if (interactive && i == selected) {
                stroke.setColor(Color.rgb(110, 168, 254));
                stroke.setStrokeWidth(Math.max(5f, Math.min(width, height) * 0.009f));
                canvas.drawPath(path, stroke);
            }
        }
    }

    private void drawPlaceholder(Canvas canvas, RectF b, int index) {
        float size = Math.max(22f, Math.min(b.width(), b.height()) * 0.075f);
        text.setTextSize(size);
        text.setColor(Color.rgb(225, 231, 240));
        canvas.drawText("写真 " + (index + 1), b.centerX(), b.centerY() - size * 0.15f, text);
        text.setTextSize(size * 0.55f);
        text.setColor(Color.rgb(155, 166, 184));
        canvas.drawText("タップして選択", b.centerX(), b.centerY() + size * 0.7f, text);
    }

    private Matrix matrixFor(ImageState st, RectF cell) {
        Bitmap bm = st.bitmap;
        float base = Math.max(cell.width() / bm.getWidth(), cell.height() / bm.getHeight());
        float scale = base * st.zoom;
        float drawW = bm.getWidth() * scale;
        float drawH = bm.getHeight() * scale;
        float dx = cell.centerX() - drawW / 2f + st.offsetX * cell.width();
        float dy = cell.centerY() - drawH / 2f + st.offsetY * cell.height();
        Matrix m = new Matrix();
        m.setScale(scale, scale);
        m.postTranslate(dx, dy);
        return m;
    }

    private void clampOffsets(int index) {
        ImageState st = images.get(index);
        if (st.bitmap == null || getWidth() == 0 || getHeight() == 0) return;
        List<Path> paths = buildPaths(getWidth(), getHeight());
        if (index >= paths.size()) return;
        RectF cell = new RectF();
        paths.get(index).computeBounds(cell, true);
        float base = Math.max(cell.width() / st.bitmap.getWidth(), cell.height() / st.bitmap.getHeight());
        float scale = base * st.zoom;
        float drawW = st.bitmap.getWidth() * scale;
        float drawH = st.bitmap.getHeight() * scale;
        float maxDx = Math.max(0f, (drawW - cell.width()) / 2f);
        float maxDy = Math.max(0f, (drawH - cell.height()) / 2f);
        float dx = st.offsetX * cell.width();
        float dy = st.offsetY * cell.height();
        dx = Math.max(-maxDx, Math.min(maxDx, dx));
        dy = Math.max(-maxDy, Math.min(maxDy, dy));
        st.offsetX = cell.width() > 0 ? dx / cell.width() : 0f;
        st.offsetY = cell.height() > 0 ? dy / cell.height() : 0f;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        scaleDetector.onTouchEvent(event);
        float x = event.getX();
        float y = event.getY();

        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: {
                int hit = hitTest(x, y);
                if (hit >= 0) {
                    selected = hit;
                    if (listener != null) listener.onSelectionChanged(selected);
                    invalidate();
                }
                lastX = x;
                lastY = y;
                moved = false;
                return true;
            }
            case MotionEvent.ACTION_MOVE: {
                if (!scaleDetector.isInProgress()) {
                    float dx = x - lastX;
                    float dy = y - lastY;
                    if (Math.hypot(dx, dy) > 2.0) moved = true;
                    ImageState st = images.get(selected);
                    if (st.bitmap != null) {
                        List<Path> paths = buildPaths(getWidth(), getHeight());
                        RectF cell = new RectF();
                        paths.get(selected).computeBounds(cell, true);
                        if (cell.width() > 0 && cell.height() > 0) {
                            st.offsetX += dx / cell.width();
                            st.offsetY += dy / cell.height();
                            clampOffsets(selected);
                            invalidate();
                            changed();
                        }
                    }
                }
                lastX = x;
                lastY = y;
                return true;
            }
            case MotionEvent.ACTION_UP: {
                if (!moved && !scaleDetector.isInProgress()) {
                    ImageState st = images.get(selected);
                    if (st.bitmap == null && listener != null) listener.onRequestImage(selected);
                    performClick();
                }
                return true;
            }
            case MotionEvent.ACTION_CANCEL:
                return true;
            default:
                return true;
        }
    }

    @Override
    public boolean performClick() {
        super.performClick();
        return true;
    }

    private int hitTest(float x, float y) {
        List<Path> paths = buildPaths(getWidth(), getHeight());
        Region clip = new Region(0, 0, getWidth(), getHeight());
        for (int i = preset.cells - 1; i >= 0; i--) {
            Region r = new Region();
            r.setPath(paths.get(i), clip);
            if (r.contains((int) x, (int) y)) return i;
        }
        return -1;
    }

    private List<Path> buildPaths(int w, int h) {
        List<float[]> polygons = normalizedPolygons();
        List<Path> result = new ArrayList<>();
        for (float[] pts : polygons) {
            Path p = new Path();
            p.moveTo(pts[0] * w, pts[1] * h);
            for (int i = 2; i < pts.length; i += 2) {
                p.lineTo(pts[i] * w, pts[i + 1] * h);
            }
            p.close();
            result.add(p);
        }
        return result;
    }

    private List<float[]> normalizedPolygons() {
        List<float[]> p = new ArrayList<>();
        switch (preset) {
            case H2:
                p.add(new float[]{0,0, 1,0, 1,.5f, 0,.5f});
                p.add(new float[]{0,.5f, 1,.5f, 1,1, 0,1});
                break;
            case V3:
                p.add(new float[]{0,0, .3333f,0, .3333f,1, 0,1});
                p.add(new float[]{.3333f,0, .6667f,0, .6667f,1, .3333f,1});
                p.add(new float[]{.6667f,0, 1,0, 1,1, .6667f,1});
                break;
            case H3:
                p.add(new float[]{0,0, 1,0, 1,.3333f, 0,.3333f});
                p.add(new float[]{0,.3333f, 1,.3333f, 1,.6667f, 0,.6667f});
                p.add(new float[]{0,.6667f, 1,.6667f, 1,1, 0,1});
                break;
            case DIAG2_R:
                p.add(new float[]{0,0, .64f,0, .36f,1, 0,1});
                p.add(new float[]{.64f,0, 1,0, 1,1, .36f,1});
                break;
            case DIAG2_L:
                p.add(new float[]{0,0, .36f,0, .64f,1, 0,1});
                p.add(new float[]{.36f,0, 1,0, 1,1, .64f,1});
                break;
            case DIAG3_R:
                p.add(new float[]{0,0, .43f,0, .23f,1, 0,1});
                p.add(new float[]{.43f,0, .76f,0, .56f,1, .23f,1});
                p.add(new float[]{.76f,0, 1,0, 1,1, .56f,1});
                break;
            case V2:
            default:
                p.add(new float[]{0,0, .5f,0, .5f,1, 0,1});
                p.add(new float[]{.5f,0, 1,0, 1,1, .5f,1});
                break;
        }
        return p;
    }

    private void changed() {
        if (listener != null) listener.onStateChanged();
    }
}
