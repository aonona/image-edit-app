# FoldCollage

Galaxy Z Fold8専用を前提にした、軽量な写真コラージュアプリです。

## v0.1 の機能

- Fold8カバー画面：編集領域を上、操作を下にまとめた片手向けUI
- Fold8メイン画面：編集領域を左、操作パネルを右に配置
- 2分割 / 3分割（縦・横）
- 斜め2分割（左右）/ 斜め3分割
- 各写真をドラッグで移動、ピンチで拡大縮小
- 出力比率 1:1 / 4:5 / 3:4 / 9:16 / 16:9
- 最大辺3000pxのJPEG（品質96）で `Pictures/FoldCollage` に保存
- ネットワーク通信なし
- 写真はAndroid標準のファイル選択から読み込み

## Fold8向け設計

Samsung公式仕様のカバー画面10:16、メイン画面4:3を前提に、画面幅600dpを境に操作パネルの配置を切り替えます。

## ビルド

Android Studioで開くか、Gradle 8.10.2 + Android SDK 35で以下を実行します。

```bash
gradle :app:assembleDebug
```

生成物: `app/build/outputs/apk/debug/app-debug.apk`
